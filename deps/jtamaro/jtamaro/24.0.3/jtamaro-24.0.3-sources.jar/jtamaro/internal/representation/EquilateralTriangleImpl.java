package jtamaro.internal.representation;

import jtamaro.internal.gui.RenderOptions;

import java.awt.*;
import java.awt.geom.Path2D;


// OLD
public final class EquilateralTriangleImpl extends GraphicImpl {

  private final double side;
  private final ColorImpl color;


  public EquilateralTriangleImpl(final double side, final ColorImpl color) {
    this.side = side;
    this.color = color;
    final double circumRadius = side / Math.sqrt(3);
    final double inRadius = circumRadius / 2;
    final Path2D.Double path = new Path2D.Double();
    path.moveTo(0, -circumRadius);
    path.lineTo(side / 2, inRadius);
    path.lineTo(-side / 2, inRadius);
    path.closePath();
    setPath(path);
    //setBaseY(getBBox().getMaxY());
    //addBoundingBoxLocations();
    //addLocation(Place.CENTER, 0, 0);
    //addLocation(Place.TOP, 0, -circumRadius);
    //addLocation(Place.RIGHT, side / 2, inRadius);
    //addLocation(Place.LEFT, -side / 2, inRadius);
  }

  public ColorImpl getColor() {
    return color;
  }

  @Override
  public void render(final Graphics2D g2, final RenderOptions o) {
    g2.setPaint(color.toAWT());
    g2.fill(getPath());
  }

  @Override
  public void dump(final StringBuilder sb, final String indent) {
    super.dump(sb, indent);
    appendField(sb, indent, "side", "" + side);
    appendField(sb, indent, "color", "" + color);
  }

}
