package de.aaschmid.gradle.plugins.cpd.internal;

import de.aaschmid.gradle.plugins.cpd.CpdHtmlFileReport;
import javax.inject.Inject;
import org.gradle.api.Task;
import org.gradle.api.reporting.internal.TaskGeneratedSingleFileReport;

public abstract class CpdHtmlFileReportImpl extends TaskGeneratedSingleFileReport implements CpdHtmlFileReport {

  @Inject
  public CpdHtmlFileReportImpl(String name, Task task) {
    super(name, task);
  }
}
