package de.aaschmid.gradle.plugins.cpd.internal.worker;

import de.aaschmid.gradle.plugins.cpd.internal.worker.CpdWorkParameters.Report;
import java.io.File;
import java.lang.reflect.UndeclaredThrowableException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.List;
import javax.inject.Inject;
import net.sourceforge.pmd.cpd.CPDConfiguration;
import net.sourceforge.pmd.cpd.CPDReport;
import net.sourceforge.pmd.cpd.Match;
import net.sourceforge.pmd.lang.Language;
import org.gradle.api.GradleException;
import org.gradle.workers.WorkAction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class CpdAction implements WorkAction<CpdWorkParameters> {

    private static final Logger logger = LoggerFactory.getLogger(CpdAction.class);

    private final CpdExecutor executor;
    private final CpdReporter reporter;

    @Inject
    public CpdAction() {
        executor = new CpdExecutor();
        reporter = new CpdReporter();
    }

    // Visible for testing
    CpdAction(CpdExecutor executor, CpdReporter reporter) {
        this.executor = executor;
        this.reporter = reporter;
    }

    @Override
    public void execute() {
        List<CPDReport> matches = executor.run(createCpdConfiguration(getParameters()), getParameters().getSourceFiles().getFiles());
        reporter.generate(getParameters().getReportParameters().get(), matches);
        logResult(matches);
    }

    private CPDConfiguration createCpdConfiguration(CpdWorkParameters config) {
        CPDConfiguration result = new CPDConfiguration();
        result.setSourceEncoding(Charset.forName(config.getEncoding().get()));
        result.setOnlyRecognizeLanguage(createLanguage(config.getLanguage().get(), result));
        result.setMinimumTileSize(config.getMinimumTokenCount().get());
        result.setSkipDuplicates(config.getSkipDuplicateFiles().get());
        result.setSkipLexicalErrors(config.getSkipLexicalErrors().get());
        result.setIgnoreAnnotations(config.getIgnoreAnnotations().get());
        result.setIgnoreIdentifiers(config.getIgnoreIdentifiers().get());
        result.setIgnoreLiterals(config.getIgnoreLiterals().get());
        result.setNoSkipBlocks(!config.getSkipBlocks().get());
        result.setSkipBlocksPattern(config.getSkipBlocksPattern().get());
        return result;
    }

    private void logResult(List<CPDReport> cpdReports) {
        for (CPDReport cpdReport : cpdReports) {
            final List<Match> matches = cpdReport.getMatches();
            if (matches.isEmpty()) {
                if (logger.isInfoEnabled()) {
                    logger.info("No duplicates over {} tokens found.", getParameters().getMinimumTokenCount().get());
                }
            } else {
                String message = "CPD found duplicate code.";
                Report report = getParameters().getReportParameters().get().get(0);
                if (report != null) {
                    File reportUrl = report.getDestination();
                    message += " See the report at " + asClickableFileUrl(reportUrl);
                }
                if (getParameters().getIgnoreFailures().get()) {
                    if (logger.isWarnEnabled()) {
                        logger.warn(message);
                    }
                } else {
                    throw new GradleException(message);
                }
            }
        }
    }

    private Language createLanguage(String language, CPDConfiguration configuration) {
        final Language result = configuration.getLanguageRegistry().getLanguageById(language);
        logger.info("Using CPD language class '{}' for checking duplicates.", result);
        return result;
    }

    private String asClickableFileUrl(File path) {
        // File.toURI().toString() leads to an URL like this on Mac: file:/reports/index.html
        // This URL is not recognized by the Mac console (too few leading slashes). We solve
        // this be creating an URI with an empty authority.
        try {
            return new URI("file", "", path.toURI().getPath(), null, null).toString();
        } catch (URISyntaxException e) {
            throw new UndeclaredThrowableException(e);
        }
    }
}
