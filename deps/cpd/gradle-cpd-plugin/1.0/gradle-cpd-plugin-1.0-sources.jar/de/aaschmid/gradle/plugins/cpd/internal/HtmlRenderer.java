package de.aaschmid.gradle.plugins.cpd.internal;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import net.sourceforge.pmd.cpd.CPDReport;
import net.sourceforge.pmd.cpd.CPDReportRenderer;
import net.sourceforge.pmd.cpd.Mark;
import net.sourceforge.pmd.cpd.Match;
import net.sourceforge.pmd.lang.document.Chars;
import net.sourceforge.pmd.lang.document.FileLocation;
import net.sourceforge.pmd.util.StringUtil;

public final class HtmlRenderer implements CPDReportRenderer {

  public HtmlRenderer() {
  }

  private void renderOn(CPDReport report, PrintWriter writer, Match match, int n) throws IOException {
    /*
     * %1: index
     * %2: dupLen
     * %3: numTokens
     */
    writer.write("""
        <section>
          <h2>%1$d. Code duplication of %2$d lines (%3$d tokens)</h2>
        """.formatted(n, match.getLineCount(), match.getTokenCount()));

    int i = 1;
    for (final Mark occurrence : match) {
      final FileLocation location = occurrence.getLocation();
      /*
       * %1: index
       * %2: line start
       * %3: file path
       * %4: file name
       * %5: code
       */
      writer.append("""
          <article>
            <h3>%1$d.%2$d At line %3$d of <a href="file://%4$s">%5$s</a></h3>
            <pre>
          """.formatted(
          n,
          i++,
          location.getStartLine(),
          location.getFileId().getAbsolutePath(),
          location.getFileId().getFileName()));
      final List<Chars> dupLines = StringUtil.linesWithTrimIndent(report.getSourceCodeSlice(occurrence));
      for (Chars line : dupLines) {
        line.writeFully(writer);
        writer.println();
      }
      writer.append("""
                </pre>
              </article>
              """);
    }

    writer.write("</section>");
  }


  @Override
  public void render(CPDReport report, Writer baseWriter) throws IOException {
    final PrintWriter writer = new PrintWriter(baseWriter);
    writeBegin(writer);

    int i = 1;
    for (Match match : report.getMatches()) {
      renderOn(report, writer, match, i++);
    }

    writeEnd(writer);

    writer.flush();
  }

  private void writeBegin(Writer writer) throws IOException {
    writer.append("""
        <?xml version="1.0" encoding="UTF-8"?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
        <html xmlns="http://www.w3.org/1999/xhtml">
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>PMD CPD results</title>
            <style>
              body {
                margin: 1em auto;
                max-width: 40em;
                padding: 0 0.62em;
              }
              pre {
                border: solid 1px;
                border-radius: 4px;
                font-size: 0.8em;
                overflow-x: auto;
                padding: 1ch;
                white-space: pre;
              }
            </style>
          </head>
          <body>
            <header>
              <h1>Code duplications detected by CPD</h1>
            </header>
            <main>
        """);
  }

  private void writeEnd(Writer writer) throws IOException {
    writer.append("""
            </main>
            <footer>
              <p>Report generated automatically by CPD at <time datetime="%1$s">%1$s</time></p>
            </footer>
          </body>
        </html>
        """.formatted(DateTimeFormatter.ISO_LOCAL_DATE_TIME.format(LocalDateTime.now())));
  }
}
